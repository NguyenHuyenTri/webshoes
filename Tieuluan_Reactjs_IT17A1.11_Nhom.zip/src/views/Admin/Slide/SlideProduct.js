
import React from "react";
// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

// reactstrap components
import {
    Alert,
    Card,
    CardTitle,
    CardBody,
    CardHeader,
    Row,
    Col,
    Button,
    TabPane,
    TabContent
} from "reactstrap";
import 'static/website/css/slide/admin-slide.css'
// core components
import PanelHeader from "components/Admin/PanelHeader/PanelHeader.js";
import Nav from "react-bootstrap/Nav";
import {NavItem} from "react-bootstrap";

export default  function SlideProduct() {
    
        return (
            <>
            <TabContent >
                <TabPane id="home"   aria-labelledby="home-tab">
                    hieu adfasdjfl;asdfkasjf;lsdaf
                </TabPane>
                <TabPane id="woman"   aria-labelledby="home-tab">
                    hieu adfasdjfl;asdfkasjf;lsdaf
                </TabPane>
            </TabContent>
            </>
        );
}

