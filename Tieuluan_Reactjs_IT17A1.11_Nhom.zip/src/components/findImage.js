import {img} from 'components/image/imageproduct'
import  {to_slug} from "views/to_slug";


// function findAdd() {
//     img.map((props,index)=>{
//         if (to_slug(props.name).indexOf(to_slug('')))
//     })
// }