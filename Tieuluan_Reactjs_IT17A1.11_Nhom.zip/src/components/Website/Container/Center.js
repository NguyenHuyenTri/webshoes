import React from "react";

export default function Center() {
        return(
            <div className="mag-posts-content mt-30 mb-15 p-30 box-shadow">
                <div className="trending-now-posts mb-30">
                    <div className="section-heading">
                        <h5>The Latest & Greatest</h5>
                    </div>
                </div>
            </div>
        );
}