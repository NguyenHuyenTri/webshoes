import React from "react";

export default  function  Left() {
    return(
        <div className="post-sidebar-area left-sidebar mt-30 mb-15 bg-white box-shadow">
            <div className="single-sidebar-widget p-30">
                <div className="section-heading">
                    <h5>Trending</h5>
                </div>
            </div>
            <div className="single-sidebar-widget p-30">
                xxx
            </div>
        </div>
    );
}